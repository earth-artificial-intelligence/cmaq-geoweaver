# Write your first Python code in Geoweaver
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import xgboost as xgb
import shap
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor

# Load the datasets
cbp_data = pd.read_csv('/Users/madhav/Downloads/CBP2021Data.csv')
existing_merged_data = pd.read_csv('/Users/madhav/Downloads/merged_data_cbp_airdata_flight.csv')
rural_atlas_data = pd.read_csv('/Users/madhav/Downloads/RuralAtlasSomeColumns 2.csv')
census_ua_rural = pd.read_excel('/Users/madhav/Downloads/2010_Census_ua_rural_in_2020.xlsx')
census_ua_st_list = pd.read_excel('/Users/madhav/Downloads/2020_Census_ua_st_list_all.xlsx', skiprows=3)
ua_county_data = pd.read_excel('/Users/madhav/Downloads/2020_UA_COUNTY.xlsx')
rucc_data = pd.read_excel('/Users/madhav/Downloads/Ruralurbancontinuumcodes2023.xlsx')

# Rename 'Geographic identifier code' to 'County Code' in the CBP data
cbp_data.rename(columns={'Geographic identifier code': 'County Code'}, inplace=True)
cbp_data.rename(columns={'Geographic Area Name': 'County Name'}, inplace=True)

cbp_data['County Code'] = cbp_data['County Code'].astype(str).str.zfill(5)
cbp_data['Combined County Code'] = cbp_data['County Code'].apply(lambda x: x[-5:])

# Pivot the CBP data to have industry_columns as columns and the number of establishments as values
cbp_pivot = cbp_data.pivot_table(
    index='County Name', 
    columns='Industry', 
    values='Number of establishments', 
    aggfunc='sum'
).reset_index()

print(cbp_pivot.columns)

# Remove rows with "unknown county" or "unknown city"
existing_merged_data = existing_merged_data[~existing_merged_data['County Name'].str.contains("Unknown", case=False, na=False)]
existing_merged_data = existing_merged_data[~existing_merged_data['City Name'].str.contains("Unknown", case=False, na=False)]

# Standardize county names function
def clean_county_name(name):
    if pd.isna(name):
        return ""
    name = name.lower().strip()
    # Remove specific substrings
    name = name.replace("county", "").replace("municipio", "").replace("island", "").strip()
    # Convert to title case
    name = name.title()
    return name

rural_atlas_data.rename(columns={'County': 'County Name'}, inplace=True)

# Apply the cleaning function
existing_merged_data['County Name'] = existing_merged_data['County Name'].apply(clean_county_name)
rucc_data['County Name'] = rucc_data['County_Name'].apply(clean_county_name)
ua_county_data['COUNTY_NAME'] = ua_county_data['COUNTY_NAME'].apply(clean_county_name)
rural_atlas_data['County Name'] = rural_atlas_data['County Name'].apply(clean_county_name)
cbp_pivot['County Name'] = cbp_pivot['County Name'].apply(clean_county_name)

# Filter ozone data
ozone_data_filtered = existing_merged_data[existing_merged_data['Parameter Name'] == 'Ozone']

# Calculate maximum ozone level by county
county_stats = ozone_data_filtered.groupby('County Name')['Arithmetic Mean'].agg(['max']).reset_index()
county_stats.rename(columns={'max': 'Max Ozone Level'}, inplace=True)

# Extract industry data from existing_merged_data
industry_columns = cbp_pivot.columns.tolist()
print('industry columns', industry_columns)
industry_columns.remove('County Name')
industry_columns.remove('Industries not classified')
industry_data = existing_merged_data[['County Name'] + industry_columns].drop_duplicates(subset=['County Name'])


# Merge max ozone level with other necessary features
merged_data = pd.merge(county_stats, ua_county_data, how='left', left_on='County Name', right_on='COUNTY_NAME')
merged_data = pd.merge(merged_data, rural_atlas_data, how='left', on='County Name')
#merged_data = pd.merge(merged_data, cbp_pivot, how='left', on='County Name')
merged_data = pd.merge(merged_data, industry_data, how='left', on='County Name')
print(merged_data)

merged_data = pd.merge(merged_data, rucc_data[['County Name', 'RUCC_2023']], on='County Name', how='left')


print(merged_data)


# Ensure only one row per county
merged_data = merged_data.drop_duplicates(subset=['County Name'], keep='first')

# Classify Urban and Rural based on RUCC codes
def classify_area_rucc(rucc):
    if rucc in [1, 2, 3]:
        return 'Urban'
    else:
        return 'Rural'

# Apply classification to the merged data
merged_data['Area Type'] = merged_data['RUCC_2023'].apply(classify_area_rucc)

print("done area typing")

# Debugging: Check the counts of urban and rural areas
urban_count = merged_data[merged_data['Area Type'] == 'Urban'].shape[0]
rural_count = merged_data[merged_data['Area Type'] == 'Rural'].shape[0]
print(f"Total urban areas: {urban_count}")
print(f"Total rural areas: {rural_count}")

# Convert ozone levels to ppb
merged_data['Max Ozone Level'] = merged_data['Max Ozone Level'] * 1000  # Convert from ppm to ppb


industry_columns = [col for col in cbp_pivot.columns if col not in ['County Name', 'Industries not classified']]
demo_features = ['Age65AndOlderPct2020', 'AvgHHSize', 'Ed1LessThanHSPct', 'Ed5CollegePlusPct', 'Net_InterMigrationRate_2020_2021', 'OwnHomePct', 'Under18Pct2020', 'PctEmpChange2021', 'PctEmpAgriculture', 'PctEmpConstruction', 'PctEmpManufacturing', 'PctEmpMining', 'PctEmpServices', 'PctEmpTrade', 'UnempRate2021', 'Deep_Pov_All', 'Median_HH_Inc_ACS', 'PerCapitaInc', 'Poverty_Rate_ACS', 'POPESTIMATE2021', 'PopDensity2020']
features = pd.concat([merged_data[industry_columns], merged_data[demo_features]], axis=1).fillna(0)


scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

# Step 3: Train-test split
y = merged_data['Max Ozone Level'].fillna(0)
# Train-test split (70/30)
X_train, X_test, y_train, y_test = train_test_split(features, y, test_size=0.3, random_state=42)

# Train XGBoost model with increased regularization
xgb_model = xgb.XGBRegressor(
    n_estimators=200,  # Reduce the number of trees
    max_depth=10,  # Reduce the depth of each tree
    learning_rate=0.05,  # Lower learning rate
    min_child_weight=10,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_alpha=0.1,  # Increase L1 regularization term
    reg_lambda=0.1,  # Increase L2 regularization term
    random_state=42
)

# Fit the model without early stopping
xgb_model.fit(X_train, y_train)

y_train_pred_xgb = xgb_model.predict(X_train)
y_test_pred_xgb = xgb_model.predict(X_test)
train_mse = mean_squared_error(y_train, y_train_pred_xgb)
test_mse = mean_squared_error(y_test, y_test_pred_xgb)
train_r2 = r2_score(y_train, y_train_pred_xgb)
test_r2 = r2_score(y_test, y_test_pred_xgb)
xgb_train_mae = mean_absolute_error(y_train, y_train_pred_xgb)
xgb_test_mae = mean_absolute_error(y_test, y_test_pred_xgb)
xgb_train_mape = np.mean(np.abs((y_train - y_train_pred_xgb) / y_train)) * 100
xgb_test_mape = np.mean(np.abs((y_test - y_test_pred_xgb) / y_test)) * 100

print("done with model")

print("XGBoost - Training MSE:", train_mse)
print("XGBoost - Testing MSE:", test_mse)
print("XGBoost - Training MAE:", xgb_train_mae)
print("XGBoost - Testing MAE:", xgb_test_mae)
print("XGBoost - Training MAPE:", xgb_train_mape)
print("XGBoost - Testing MAPE:", xgb_test_mape)

# Step 5: SHAP analysis
explainer_xgb = shap.Explainer(xgb_model)
shap_values_xgb = explainer_xgb(features)

print("done with initial shap")

# Add main positive contributor column
shap_values = shap_values_xgb.values
max_contrib_indices = np.argmax(shap_values, axis=1)
main_positive_contributors = features.columns[max_contrib_indices]

merged_data['Main Contributor'] = main_positive_contributors
print("done with main contributor")

# Calculate overall feature importances
xgb_feature_importances = pd.DataFrame(xgb_model.feature_importances_, index=features.columns, columns=['importance']).sort_values('importance', ascending=False)
print("xgboost feature importances:", xgb_feature_importances)



# Top 150 highest and lowest ozone levels
top_150_highest = merged_data.nlargest(150, 'Max Ozone Level')
top_150_lowest = merged_data.nsmallest(150, 'Max Ozone Level')
combined_clusters = pd.concat([top_150_highest, top_150_lowest])

# Step 7: Analyze main contributors
positive_contributors_high = top_150_highest['Main Contributor'].value_counts().rename_axis('Contributor').reset_index(name='High Ozone Count')
positive_contributors_low = top_150_lowest['Main Contributor'].value_counts().rename_axis('Contributor').reset_index(name='Low Ozone Count')

# Handle cases where the count in low ozone is zero
positive_comparison = pd.merge(positive_contributors_high, positive_contributors_low, on='Contributor', how='outer').fillna(0)
positive_comparison['Low Ozone Count'] = positive_comparison['Low Ozone Count'].replace(0, 1e-6)  # Replace 0 with a small value to avoid division by zero
positive_comparison['Percentage Change'] = ((positive_comparison['High Ozone Count'] - positive_comparison['Low Ozone Count']) / positive_comparison['Low Ozone Count']) * 100

print("positive comparison:")
print(positive_comparison)

# Summary Statistics
urban_stats = merged_data[merged_data['Area Type'] == 'Urban']['Max Ozone Level'].describe()
rural_stats = merged_data[merged_data['Area Type'] == 'Rural']['Max Ozone Level'].describe()

print("Urban Ozone Level Statistics:\n", urban_stats)
print("\nRural Ozone Level Statistics:\n", rural_stats)

# Focused Analysis
highest_ozone_city = merged_data[merged_data['Area Type'] == 'Urban'].nlargest(1, 'Max Ozone Level')
highest_ozone_rural = merged_data[merged_data['Area Type'] == 'Rural'].nlargest(1, 'Max Ozone Level')
lowest_ozone_city = merged_data[merged_data['Area Type'] == 'Urban'].nsmallest(1, 'Max Ozone Level')
lowest_ozone_rural = merged_data[merged_data['Area Type'] == 'Rural'].nsmallest(1, 'Max Ozone Level')

focused_analysis_results = {
    "highest_ozone_city": highest_ozone_city[industry_columns + demo_features + ['Max Ozone Level']],
    "highest_ozone_rural": highest_ozone_rural[industry_columns + demo_features + ['Max Ozone Level']],
    "lowest_ozone_city": lowest_ozone_city[industry_columns + demo_features + ['Max Ozone Level']],
    "lowest_ozone_rural": lowest_ozone_rural[industry_columns + demo_features + ['Max Ozone Level']],
}

print(focused_analysis_results)


# Step 10: Percentile Distribution of industry_columns
# Calculate percentile distribution of industry_columns
high_ozone_industry_columns = top_150_highest[industry_columns].apply(lambda x: np.percentile(x.dropna(), 99), axis=0)
low_ozone_industry_columns = top_150_lowest[industry_columns].apply(lambda x: np.percentile(x.dropna(), 99), axis=0)

# Identify places with industry_columns in the top percentile
def top_percentile_places(df, industry_columns, percentile=99):
    results = {}
    for industry in industry_columns:
        threshold = np.percentile(df[industry].dropna(), percentile)
        top_places = df[df[industry] >= threshold]
        results[industry] = top_places[['County Name', industry]]
    return results

high_percentile_places = top_percentile_places(top_150_highest, industry_columns)
low_percentile_places = top_percentile_places(top_150_lowest, industry_columns)

print("High Percentile Places:\n", high_percentile_places)
print("Low Percentile Places:\n", low_percentile_places)


