# Write your first Python code in Geoweaver

import pandas as pd
import pandas as pd
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score
import shap
import numpy as np

# Load the data file
file_path = '/Users/sahiti/Downloads/updated_annual_conc_zipcode_final.csv'
data_df = pd.read_csv(file_path)

# Pivot the table
pivot_table = data_df.pivot_table(index=['Site Num', 'Address', 'Latitude_x', 'Longitude_x','County Name', 'City Name', 'Zipcode'], 
                                  columns='Parameter Name', values='Arithmetic Mean')

# Reset the index to ensure all required columns are part of the dataframe
pivot_table.reset_index(inplace=True)

# Drop rows where Ozone is NaN
pivot_table_cleaned = pivot_table.dropna(subset=['Ozone'])
# Drop columns that are 100% NaN
pivot_table_cleaned = pivot_table_cleaned.dropna(axis=1, how='all')

# Clean column names to remove invalid characters for XGBoost
pivot_table_cleaned.columns = pivot_table_cleaned.columns.str.replace('[', '_').str.replace(']', '_').str.replace('<', '_')

# Impute remaining NaN values with zeros
pivot_table_cleaned = pivot_table_cleaned.fillna(0)

print(pivot_table_cleaned)

# Define features (all 'Parameter Name' columns) and target (Ozone)
features = pivot_table_cleaned.drop(columns=['Site Num', 'Address', 'Latitude_x', 'Longitude_x', 'City Name','County Name', 'Zipcode', 'Ozone'])
target = pivot_table_cleaned['Ozone']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# Train the XGBoost model
model = XGBRegressor()
model.fit(X_train, y_train)

# Make predictions and evaluate the model
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
mape = mean_absolute_percentage_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"Mean Absolute Percentage Error: {mape}")
print(f"R-squared: {r2}")

# Use SHAP to find the main positive contributor for each row
explainer = shap.Explainer(model, X_train)

shap_values_train = explainer(X_train)
shap_values_test = explainer(X_test)

print("done with shap")

# Combine SHAP values and indices
shap_values_combined = np.concatenate([shap_values_train.values, shap_values_test.values])
X_combined = pd.concat([X_train, X_test])
shap_combined_indices = np.concatenate([X_train.index, X_test.index])

print("starting main contributors")
# Define a function to get the main positive contributor
def get_main_positive_contributor(shap_values, features):
    main_contributors = []
    main_contributors_values = []
    
    for i in range(features.shape[0]):
        shap_vals = shap_values[i]
        if len(shap_vals) > 0:  # Ensure shap_vals is not empty
            max_shap_idx = np.argmax(shap_vals)
            main_contributors.append(features.columns[max_shap_idx])
            main_contributors_values.append(shap_vals[max_shap_idx])
        else:
            main_contributors.append(np.nan)
            main_contributors_values.append(np.nan)
    
    return pd.DataFrame({
        'Main Positive Contributor': main_contributors,
        'Contributor Value': main_contributors_values
    }, index=features.index)

# Get the main positive contributors for the combined set
main_contributors_combined_df = get_main_positive_contributor(shap_values_combined, X_combined)
print("done with main contributors")

# Add indices to main_contributors_combined_df
main_contributors_combined_df.index = shap_combined_indices

# Merge the main contributors back with the original pivot_table_cleaned
result_df = pivot_table_cleaned.copy()
result_df['Main Positive Contributor'] = main_contributors_combined_df['Main Positive Contributor']
result_df['Contributor Value'] = main_contributors_combined_df['Contributor Value']

print(result_df)

