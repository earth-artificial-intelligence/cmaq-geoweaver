# Write your first Python code in Geoweaver
import pandas as pd
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score
import shap
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import folium
from folium import Choropleth
import matplotlib.colors as mcolors

# Load the business data file
business_data_file_path = '/Users/sahiti/Downloads/zip_code_business_data_with_all_naics_v2.csv'
business_data_df = pd.read_csv(business_data_file_path)

# Create the pivot table
pivot_table = business_data_df.pivot_table(index='zip code', columns='NAICS2017_LABEL', values='ESTAB', aggfunc='sum')

# Drop columns where all elements are NaN
pivot_table_cleaned = pivot_table.dropna(axis=1, how='all')

# Drop rows where all elements are NaN
pivot_table_cleaned = pivot_table_cleaned.dropna(how='all')

# Reset the index to ensure zip code remains a column
pivot_table_cleaned.reset_index(inplace=True)

# Load the other data files
annual_conc_path = "/Users/sahiti/Downloads/updated_annual_conc_zipcode_final.csv"
df = pd.read_csv(annual_conc_path)

demo_data = pd.read_csv("/Users/sahiti/Downloads/zip_code_demographics.csv")

# Convert the Zipcode columns to string type
df['Zipcode'] = df['Zipcode'].astype(str)
demo_data['zip'] = demo_data['zip'].astype(str)
pivot_table_cleaned['zip code'] = pivot_table_cleaned['zip code'].astype(str)

# Merge the datasets
merged_df = pd.merge(df, demo_data, left_on="Zipcode", right_on="zip", how="left")
merged_df = merged_df.loc[:, ~merged_df.columns.duplicated()]
merged_df = pd.merge(merged_df, pivot_table_cleaned, left_on="Zipcode", right_on="zip code", how="left")

# Load the RUCA data file
ruca_data_file_path = '/Users/sahiti/Downloads/RUCA2010zipcode.xlsx'
ruca_df = pd.read_excel(ruca_data_file_path, sheet_name='Data')

# Convert ZIP_CODE to string for consistent merging
ruca_df['ZIP_CODE'] = ruca_df['ZIP_CODE'].astype(str)

# Merge with RUCA data
merged_df = pd.merge(merged_df, ruca_df[['ZIP_CODE', 'RUCA1']], left_on='Zipcode', right_on='ZIP_CODE', how='left')

# Drop rows with NaNs in the RUCA1 column
merged_df = merged_df.dropna(subset=['RUCA1'])

# Classify as urban or rural
merged_df['Area Type'] = merged_df['RUCA1'].apply(lambda x: 'Urban' if x in [1, 2, 3] else 'Rural')

print("done with all merging")


# Drop unnecessary columns from ozone_filtered_data
#ozone_filtered_data = ozone_filtered_data[["Zipcode"] + list(X.columns) + ["Arithmetic Mean", "main_positive_contributor", "contributor_score"]]

# Filter for Ozone data
ozone_filtered_data = merged_df[merged_df["Parameter Name"] == "Ozone"]

print(ozone_filtered_data['lat'])

# Prepare the data for the model
features = pd.concat([ozone_filtered_data[demo_data.columns], ozone_filtered_data[pivot_table_cleaned.columns]], axis=1)

ozone_filtered_data["Arithmetic Mean"] = ozone_filtered_data["Arithmetic Mean"] * 1000  # converting from ppm to ppb
features.fillna(0, inplace=True)
print(features.columns)

# Step 1: Filter urban and rural areas based on specific RUCA codes
urban_areas_specific = ozone_filtered_data[ozone_filtered_data['RUCA1'].isin([1, 2])]
rural_areas_specific = ozone_filtered_data[ozone_filtered_data['RUCA1'].isin([7, 8, 9, 10])]

# Step 2: Compare average ozone levels between urban and rural areas
average_urban_ozone = urban_areas_specific['Arithmetic Mean'].mean()
average_rural_ozone = rural_areas_specific['Arithmetic Mean'].mean()

print(f"Average Ozone Levels in Urban Areas: {average_urban_ozone} ppb")
print(f"Average Ozone Levels in Rural Areas: {average_rural_ozone} ppb")

# Drop unnecessary columns
X = features.drop(columns=["zip", "lat", "lng", "city", 'state_id', 'state_name', 'county_name', 'zip code'])
y = ozone_filtered_data["Arithmetic Mean"]

# Ensure the index is the same
ozone_filtered_data = ozone_filtered_data.loc[features.index]
print(ozone_filtered_data)

# Keep track of the original indices
original_indices = ozone_filtered_data.index

# Split the data into training and testing sets
X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(X, y, original_indices, test_size=0.2, random_state=42)

# Train the XGBoost model
model = XGBRegressor()
model.fit(X_train, y_train)

# Make predictions and evaluate the model
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
mape = mean_absolute_percentage_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"Mean Absolute Percentage Error: {mape}")
print(f"R-squared: {r2}")

# Step 3: Select the highest ozone urban area and the lowest ozone rural area for focused analysis
highest_urban_area = urban_areas_specific.loc[urban_areas_specific['Arithmetic Mean'].idxmax()]
lowest_rural_area = rural_areas_specific.loc[rural_areas_specific['Arithmetic Mean'].idxmin()]

print(highest_urban_area['city'])
print(lowest_rural_area['city'])


columns_to_drop = ['dist2_large_airport', 'number_of_returns', 'adjusted_gross_income', 'dist_to_shore', 'dist_highway', 'total_income_amount', 'number_of_business']


# Prepare data for SHAP analysis
urban_features = highest_urban_area[X.columns].drop(columns=columns_to_drop).values.reshape(1, -1)
rural_features = lowest_rural_area[X.columns].drop(columns=columns_to_drop).values.reshape(1, -1)


print("starting focused analysis urban vs rural")

# Step 4: Identify the top contributing features to ozone levels in both areas using SHAP values
explainer = shap.Explainer(model, X_train)

urban_shap_values = explainer(urban_features)
rural_shap_values = explainer(rural_features)

urban_contributors = pd.DataFrame({'Feature': X_train.columns, 'SHAP Value': urban_shap_values.values.flatten()})
rural_contributors = pd.DataFrame({'Feature': X_train.columns, 'SHAP Value': rural_shap_values.values.flatten()})

urban_top_contributors = urban_contributors.nlargest(5, 'SHAP Value')
rural_top_contributors = rural_contributors.nlargest(5, 'SHAP Value')

print("Top contributing features in the highest ozone urban area:")
print(urban_top_contributors)

print("Top contributing features in the lowest ozone rural area:")
print(rural_top_contributors)

# Step 5: Analyze and interpret the results
# Plot the distribution of ozone levels in urban vs. rural areas
plt.figure(figsize=(10, 6))
sns.boxplot(x='Area Type', y='Arithmetic Mean', data=ozone_filtered_data)
plt.title('Ozone Levels in Urban vs. Rural Areas')
plt.xlabel('Area Type')
plt.ylabel('Ozone Level (ppb)')
#plt.show()

# Plot SHAP values for the highest ozone urban area
plt.figure(figsize=(10, 6))
shap.plots.bar(urban_shap_values)  # Changed to shap.plots.bar to handle Explanation object
plt.title('Top Contributing Features to Ozone Levels in the Highest Ozone Urban Area')
#plt.show()

# Plot SHAP values for the lowest ozone rural area
plt.figure(figsize=(10, 6))
shap.plots.bar(rural_shap_values)  # Changed to shap.plots.bar to handle Explanation object
plt.title('Top Contributing Features to Ozone Levels in the Lowest Ozone Rural Area')
#plt.show()

# 1. Top 150 places with highest ozone and 150 places with lowest ozone
top_150_high_ozone = ozone_filtered_data.nlargest(150, 'Arithmetic Mean')
top_150_low_ozone = ozone_filtered_data.nsmallest(150, 'Arithmetic Mean')

# 2. Calculate the percentage increase in "Total for all sectors"
average_high_ozone_activity = top_150_high_ozone['Total for all sectors'].mean()
average_low_ozone_activity = top_150_low_ozone['Total for all sectors'].mean()

percentage_increase = ((average_high_ozone_activity - average_low_ozone_activity) / average_low_ozone_activity) * 100

print(f"Percentage increase in total industrial activity in high ozone places compared to low ozone places: {percentage_increase:.2f}%")

# Step 2: Calculate the 90th percentile for "Total for all sectors"
total_industries_90th_percentile = ozone_filtered_data['Total for all sectors'].quantile(0.90)

# Step 3: Count the number of places in the high ozone cluster that have industries in the 99th percentile
high_ozone_90th_percentile_count = top_150_high_ozone[top_150_high_ozone['Total for all sectors'] >= total_industries_90th_percentile].shape[0]
low_ozone_90th_percentile_count = top_150_low_ozone[top_150_low_ozone['Total for all sectors'] >= total_industries_90th_percentile].shape[0]

# Step 4: Print the results
print(f"Number of places in the high ozone cluster with industries in the 99th percentile: {high_ozone_90th_percentile_count}")
print(f"Number of places in the low ozone cluster with industries in the 90th percentile: {low_ozone_90th_percentile_count}")

# Step 5: Calculate the percentage of places with industries in the 90th percentile
high_ozone_90th_percentile_percentage = (high_ozone_90th_percentile_count / 150) * 100
low_ozone_90th_percentile_percentage = (low_ozone_90th_percentile_count / 150) * 100

print(f"Percentage of places in the high ozone cluster with industries in the 90th percentile: {high_ozone_90th_percentile_percentage:.2f}%")
print(f"Percentage of places in the low ozone cluster with industries in the 90th percentile: {low_ozone_90th_percentile_percentage:.2f}%")


# Visualization of the difference in industrial activity
plt.figure(figsize=(10, 6))
sns.boxplot(data=[top_150_high_ozone['Total for all sectors'], top_150_low_ozone['Total for all sectors']], palette="Set3")
plt.xticks([0, 1], ['High Ozone', 'Low Ozone'])
plt.title('Total Industrial Activity: High Ozone vs Low Ozone Places')
plt.ylabel('Total Industrial Activity')
#plt.show()

plt.figure(figsize=(10, 6))
sns.histplot(ozone_filtered_data['Total for all sectors'], bins=30, kde=True, color='skyblue')
plt.axvline(total_industries_90th_percentile, color='red', linestyle='dashed', linewidth=2)
plt.title('Distribution of Total for All Sectors with 90th Percentile Marked')
plt.xlabel('Total for All Sectors')
plt.ylabel('Frequency')
#plt.show()

plt.figure(figsize=(10, 6))
sns.barplot(x=['High Ozone Cluster'], y=[high_ozone_90th_percentile_percentage], palette="Set3")
plt.ylim(0, 100)
plt.title('Percentage of High Ozone Cluster in Top 90th Percentile of Total Industries')
plt.ylabel('Percentage (%)')
#plt.show()

# Create labels for high and low ozone places
top_150_high_ozone['Ozone Category'] = 'High Ozone'
top_150_low_ozone['Ozone Category'] = 'Low Ozone'

# Combine the two dataframes
combined_df = pd.concat([top_150_high_ozone, top_150_low_ozone])

# Create the scatter plot
plt.figure(figsize=(10, 6))
sns.scatterplot(x='Ozone Category', y='Total for all sectors', data=combined_df, hue='Ozone Category', palette="Set3")
plt.title('Total Industrial Activity: High Ozone vs Low Ozone Places')
plt.ylabel('Total Industrial Activity')
#plt.show()

# Prepare data for SHAP analysis
high_ozone_features = top_150_high_ozone[X.columns]
low_ozone_features = top_150_low_ozone[X.columns]

# Calculate SHAP values
explainer = shap.Explainer(model, X_train)
high_ozone_shap_values = explainer(high_ozone_features)
low_ozone_shap_values = explainer(low_ozone_features)

# Convert SHAP values to DataFrame for easier handling
high_ozone_shap_df = pd.DataFrame(high_ozone_shap_values.values, columns=X.columns)
low_ozone_shap_df = pd.DataFrame(low_ozone_shap_values.values, columns=X.columns)

# Filter out the features you don't want to see in the plot
filtered_high_ozone_shap_df = high_ozone_shap_df.drop(columns=columns_to_drop)
filtered_low_ozone_shap_df = low_ozone_shap_df.drop(columns=columns_to_drop)

# Summarize SHAP values for filtered features
high_ozone_contributors = pd.DataFrame({'Feature': filtered_high_ozone_shap_df.columns, 'SHAP Value': filtered_high_ozone_shap_df.abs().mean()})
low_ozone_contributors = pd.DataFrame({'Feature': filtered_low_ozone_shap_df.columns, 'SHAP Value': filtered_low_ozone_shap_df.abs().mean()})

# Visualize SHAP values for the high ozone cluster
plt.figure(figsize=(10, 6))
shap.summary_plot(filtered_high_ozone_shap_df.values, high_ozone_features.drop(columns=columns_to_drop), plot_type="bar")
plt.title('Top Contributing Features to HIGH Ozone Cluster (Filtered)')

# Visualize SHAP values for the low ozone cluster
plt.figure(figsize=(10, 6))
shap.summary_plot(filtered_low_ozone_shap_df.values, low_ozone_features.drop(columns=columns_to_drop), plot_type="bar")
plt.title('Top Contributing Features to HIGH Ozone Cluster (Filtered)')

# # Summarize SHAP values
# high_ozone_contributors = pd.DataFrame({'Feature': X_train.columns, 'SHAP Value': high_ozone_shap_values.values.mean(axis=0)})
# low_ozone_contributors = pd.DataFrame({'Feature': X_train.columns, 'SHAP Value': low_ozone_shap_values.values.mean(axis=0)})

high_ozone_top_contributors = high_ozone_contributors.nlargest(5, 'SHAP Value')
low_ozone_top_contributors = low_ozone_contributors.nlargest(5, 'SHAP Value')

print("Top contributing features in the HIGH ozone cluster:")
print(high_ozone_top_contributors)

print("Top contributing features in the LOW ozone cluster:")
print(low_ozone_top_contributors)


print("starting the main contributor shap")

shap_values_train = explainer(X_train)
shap_values_test = explainer(X_test)

print("done with shap")

def get_main_contributors(shap_values, features, exclude_columns):
    main_contributors = []
    main_contributors_values = []
    
    for i in range(features.shape[0]):
        shap_vals = shap_values[i].values if hasattr(shap_values[i], 'values') else shap_values[i]
        if len(shap_vals) > 0:  # Ensure shap_vals is not empty
            filtered_shap_vals = [shap_vals[idx] for idx in range(len(shap_vals)) if features.columns[idx] not in exclude_columns]
            max_shap_idx = np.argmax(np.abs(filtered_shap_vals))
            actual_idx = [idx for idx in range(len(shap_vals)) if features.columns[idx] not in exclude_columns][max_shap_idx]
            main_contributors.append(features.columns[actual_idx])
            main_contributors_values.append(filtered_shap_vals[max_shap_idx])
        else:
            main_contributors.append(np.nan)
            main_contributors_values.append(np.nan)
    
    return pd.DataFrame({
        'Main Contributor': main_contributors,
        'Main Contributor Value': main_contributors_values
    }, index=features.index)

exclude_columns = ['dist2_large_airport', 'number_of_returns', 'adjusted_gross_income', 'dist_to_shore', 'dist_highway', 'total_income_amount', 'number_of_business']

contributor_df_train = get_main_contributors(shap_values_train, X_train, exclude_columns)
contributor_df_test = get_main_contributors(shap_values_test, X_test, exclude_columns)

print("done with contributor")

contributor_df_train = contributor_df_train.reset_index(drop=True)
contributor_df_test = contributor_df_test.reset_index(drop=True)

contributor_df_train['Set'] = 'Train'
contributor_df_test['Set'] = 'Test'

contributor_df_train.index = idx_train
contributor_df_test.index = idx_test

# Combine SHAP values from train and test sets
contributor_df = pd.concat([contributor_df_train, contributor_df_test], axis=0).sort_index()
print("done with shap 2")
# Determine the main positive contributor for each row
ozone_filtered_data['main_positive_contributor'] = contributor_df['Main Contributor']
ozone_filtered_data['contributor_score'] = contributor_df['Main Contributor Value']

print("done merging with ozone_filtered_data")

ozone_filtered_data = ozone_filtered_data.dropna(subset=['lat'])

ozone_filtered_data = ozone_filtered_data.dropna(subset=['lng'])

print('creating map')

# Define a function to get a color from a gradient
def get_gradient_color(value, vmin, vmax):
    norm = mcolors.Normalize(vmin=vmin, vmax=vmax)
    cmap = mcolors.LinearSegmentedColormap.from_list("", ["green", "yellow", "red"])
    return cmap(norm(value))

# Prepare the map (industry only)
m = folium.Map(location=[39.8283, -98.5795], zoom_start=5)

# Calculate min and max for the color scaling
vmin = ozone_filtered_data['Arithmetic Mean'].min()
vmax = ozone_filtered_data['Arithmetic Mean'].max()

# Add circles to the map with gradient colors
for i, row in ozone_filtered_data.iterrows():
    folium.CircleMarker(
        location=[row['lat'], row['lng']],
        radius=row['Total for all sectors'] / 100,  # Adjust the size as needed
        color=get_gradient_color(row['Arithmetic Mean'], vmin, vmax),
        fill=True,
        fill_color=get_gradient_color(row['Arithmetic Mean'], vmin, vmax),
        fill_opacity=0.7,
        popup=folium.Popup(f"Ozone Level: {row['Arithmetic Mean']} ppb<br>Main Positive Contributor: {row['main_positive_contributor']}ppb<br>Main Emission Contributor: {row['main_positive_emission_contributor']}", max_width=300)
    ).add_to(m)
    
# Save the map
m.save('ozone_map_v4.html')




