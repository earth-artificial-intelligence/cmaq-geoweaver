# Write your first Python code in Geoweaver
import pandas as pd
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score
import shap
import folium
from folium.plugins import MarkerCluster
import matplotlib.cm as cm
from matplotlib.colors import Normalize, to_hex
import numpy as np

# Load the business data file
business_data_file_path = 'zip_code_business_data_with_all_naics_v2.csv'
business_data_df = pd.read_csv(business_data_file_path)

# Create the pivot table
pivot_table = business_data_df.pivot_table(index='zip code', columns='NAICS2017_LABEL', values='ESTAB', aggfunc='sum')

# Drop columns where all elements are NaN
pivot_table_cleaned = pivot_table.dropna(axis=1, how='all')

# Drop rows where all elements are NaN
pivot_table_cleaned = pivot_table_cleaned.dropna(how='all')

# Reset the index to ensure zip code remains a column
pivot_table_cleaned.reset_index(inplace=True)

# Load the other data files
annual_conc_path = "updated_annual_conc_zipcode_final.csv"
df = pd.read_csv(annual_conc_path)

demo_data = pd.read_csv("zip_code_demographics.csv")

# Convert the Zipcode columns to string type
df['Zipcode'] = df['Zipcode'].astype(str)
demo_data['zip'] = demo_data['zip'].astype(str)
pivot_table_cleaned['zip code'] = pivot_table_cleaned['zip code'].astype(str)

# Merge the datasets
merged_df = pd.merge(df, demo_data, left_on="Zipcode", right_on="zip", how="left")
merged_df = merged_df.loc[:, ~merged_df.columns.duplicated()]
merged_df = pd.merge(merged_df, pivot_table_cleaned, left_on="Zipcode", right_on="zip code", how="left")

# Load the RUCA data file
ruca_data_file_path = 'RUCA2010zipcode.xlsx'
ruca_df = pd.read_excel(ruca_data_file_path, sheet_name='Data')

# Convert ZIP_CODE to string for consistent merging
ruca_df['ZIP_CODE'] = ruca_df['ZIP_CODE'].astype(str)

# Merge with RUCA data
merged_df = pd.merge(merged_df, ruca_df[['ZIP_CODE', 'RUCA1']], left_on='Zipcode', right_on='ZIP_CODE', how='left')

# Drop rows with NaNs in the RUCA1 column
merged_df = merged_df.dropna(subset=['RUCA1'])

# Classify as urban or rural
merged_df['Area Type'] = merged_df['RUCA1'].apply(lambda x: 'Urban' if x in [1, 2, 3] else 'Rural')

print("done with all merging")

def get_shap_emissions(file_path):
    # Load the data file
    data_df = pd.read_csv(file_path)

    # Pivot the table
    pivot_table = data_df.pivot_table(index=['Site Num', 'Address', 'Latitude_x', 'Longitude_x','County Name', 'City Name', 'Zipcode'], 
                                      columns='Parameter Name', values='Arithmetic Mean')

    # Reset the index to ensure all required columns are part of the dataframe
    pivot_table.reset_index(inplace=True)

    # Drop rows where Ozone is NaN
    pivot_table_cleaned = pivot_table.dropna(subset=['Ozone'])
    # Drop columns that are 100% NaN
    pivot_table_cleaned = pivot_table_cleaned.dropna(axis=1, how='all')

    # Clean column names to remove invalid characters for XGBoost
    pivot_table_cleaned.columns = pivot_table_cleaned.columns.str.replace('[', '_').str.replace(']', '_').str.replace('<', '_')

    # Impute remaining NaN values with zeros
    pivot_table_cleaned = pivot_table_cleaned.fillna(0)

    print(pivot_table_cleaned)

    # Define features (all 'Parameter Name' columns) and target (Ozone)
    features = pivot_table_cleaned.drop(columns=['Site Num', 'Address', 'Latitude_x', 'Longitude_x', 'City Name','County Name', 'Zipcode', 'Ozone'])
    target = pivot_table_cleaned['Ozone']

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

    # Train the XGBoost model
    model = XGBRegressor()
    model.fit(X_train, y_train)

    # Make predictions and evaluate the model
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    mape = mean_absolute_percentage_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    print(f"Mean Squared Error: {mse}")
    print(f"Mean Absolute Percentage Error: {mape}")
    print(f"R-squared: {r2}")

    # Use SHAP to find the main positive contributor for each row
    explainer = shap.Explainer(model, X_train)

    shap_values_train = explainer(X_train)
    shap_values_test = explainer(X_test)

    print("done with shap")

    # Combine SHAP values and indices
    shap_values_combined = np.concatenate([shap_values_train.values, shap_values_test.values])
    X_combined = pd.concat([X_train, X_test])
    shap_combined_indices = np.concatenate([X_train.index, X_test.index])

    print("starting main contributors")
    # Define a function to get the main positive contributor
    def get_main_positive_contributor(shap_values, features):
        main_contributors = []
        main_contributors_values = []
        
        for i in range(features.shape[0]):
            shap_vals = shap_values[i]
            if len(shap_vals) > 0:  # Ensure shap_vals is not empty
                max_shap_idx = np.argmax(shap_vals)
                main_contributors.append(features.columns[max_shap_idx])
                main_contributors_values.append(shap_vals[max_shap_idx])
            else:
                main_contributors.append(np.nan)
                main_contributors_values.append(np.nan)
        
        return pd.DataFrame({
            'Main Positive Contributor': main_contributors,
            'Contributor Value': main_contributors_values
        }, index=features.index)

    # Get the main positive contributors for the combined set
    main_contributors_combined_df = get_main_positive_contributor(shap_values_combined, X_combined)
    print("done with main contributors")

    # Add indices to main_contributors_combined_df
    main_contributors_combined_df.index = shap_combined_indices

    # Merge the main contributors back with the original pivot_table_cleaned
    result_df = pivot_table_cleaned.copy()
    result_df['Main Positive Emission Contributor'] = main_contributors_combined_df['Main Positive Contributor']
    result_df['Emission Contributor Value'] = main_contributors_combined_df['Contributor Value']
    
    return result_df


# Drop unnecessary columns from ozone_filtered_data
#ozone_filtered_data = ozone_filtered_data[["Zipcode"] + list(X.columns) + ["Arithmetic Mean", "main_positive_contributor", "contributor_score"]]


emissions_shap_df = get_shap_emissions(annual_conc_path)
print("created emissions_shap_df")

# Filter for Ozone data
ozone_filtered_data = merged_df[merged_df["Parameter Name"] == "Ozone"]

print(ozone_filtered_data['lat'])

# Prepare the data for the model
features = pd.concat([ozone_filtered_data[demo_data.columns], ozone_filtered_data[pivot_table_cleaned.columns]], axis=1)

ozone_filtered_data["Arithmetic Mean"] = ozone_filtered_data["Arithmetic Mean"] * 1000  # converting from ppm to ppb
features.fillna(0, inplace=True)
print(features.columns)

# Drop unnecessary columns
X = features.drop(columns=["zip", "lat", "lng", "city", 'state_id', 'state_name', 'county_name', 'zip code'])
y = ozone_filtered_data["Arithmetic Mean"]

# Ensure the index is the same
ozone_filtered_data = ozone_filtered_data.loc[features.index]
print(ozone_filtered_data)

# Keep track of the original indices
original_indices = ozone_filtered_data.index

# Split the data into training and testing sets
X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(X, y, original_indices, test_size=0.2, random_state=42)

# Train the XGBoost model
model = XGBRegressor()
model.fit(X_train, y_train)

# Make predictions and evaluate the model
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
mape = mean_absolute_percentage_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"Mean Absolute Percentage Error: {mape}")
print(f"R-squared: {r2}")

# Use SHAP to find the main positive contributor for each row
explainer = shap.Explainer(model, X_train)

shap_values_test = explainer(X_test)

print("done with shap")



# Determine the main positive contributor for each row in X_test
def get_main_contributors(shap_values, features, exclude_columns):
    main_contributors = []
    main_contributors_values = []

    for i in range(features.shape[0]):
        shap_vals = shap_values[i].values if hasattr(shap_values[i], 'values') else shap_values[i]
        if len(shap_vals) > 0:  # Ensure shap_vals is not empty
            filtered_shap_vals = [shap_vals[idx] for idx in range(len(shap_vals)) if features.columns[idx] not in exclude_columns]
            max_shap_idx = np.argmax(np.abs(filtered_shap_vals))
            actual_idx = [idx for idx in range(len(shap_vals)) if features.columns[idx] not in exclude_columns][max_shap_idx]
            main_contributors.append(features.columns[actual_idx])
            main_contributors_values.append(filtered_shap_vals[max_shap_idx])
        else:
            main_contributors.append(np.nan)
            main_contributors_values.append(np.nan)

    return pd.DataFrame({
        'Main Contributor': main_contributors,
        'Main Contributor Value': main_contributors_values
    }, index=features.index)

exclude_columns = ['dist2_large_airport', 'number_of_returns', 'adjusted_gross_income', 'dist_to_shore', 'dist_highway', 'total_income_amount', 'number_of_business']

contributor_df_test = get_main_contributors(shap_values_test, X_test, exclude_columns)

print("done with contributor")

# Reset index for merging
contributor_df_test = contributor_df_test.reset_index(drop=True)
contributor_df_test.index = idx_test

# Combine SHAP values with the ozone data
ozone_filtered_data_test = ozone_filtered_data.loc[idx_test]
ozone_filtered_data_test['main_positive_contributor'] = contributor_df_test['Main Contributor']
ozone_filtered_data_test['contributor_score'] = contributor_df_test['Main Contributor Value']

# Merge with emissions_shap_df
ozone_filtered_data_test = ozone_filtered_data_test.merge(emissions_shap_df, left_on='Zipcode', right_on='Zipcode', how='left')

# Ensure there are no NaN values in the latitude and longitude columns
ozone_filtered_data_test = ozone_filtered_data_test.dropna(subset=['lat', 'lng'])


print("done merging with emissions", ozone_filtered_data_test)

print('creating map')

# Sample 50% of the data
ozone_filtered_data_sampled = ozone_filtered_data_test.sample(frac=0.3, random_state=42)

# Function to normalize and convert ozone levels to a color
def get_color(ozone_level, min_val, max_val):
    norm = Normalize(vmin=min_val, vmax=max_val)
    cmap = cm.get_cmap('YlOrRd')
    return to_hex(cmap(norm(ozone_level)))

# Prepare the map
m = folium.Map(location=[39.8283, -98.5795], zoom_start=5)

# Calculate min and max for the color scaling
min_val = ozone_filtered_data_sampled['Arithmetic Mean'].min()
max_val = ozone_filtered_data_sampled['Arithmetic Mean'].max()

# Add MarkerCluster to the map
marker_cluster = MarkerCluster().add_to(m)

# Add circles to the map with gradient colors
for i, row in ozone_filtered_data_sampled.iterrows():
    popup_text = (
        f"Ozone Level: {row['Arithmetic Mean']} ppb<br>"
        f"Main Positive Contributor: {row['main_positive_contributor']} ppb<br>"
        f"Main Emission Contributor: {row['Main Positive Emission Contributor']}"
    )
    folium.CircleMarker(
        location=[row['lat'], row['lng']],
        radius=5,  # Adjust the size as needed
        color=get_color(row['Arithmetic Mean'], min_val, max_val),
        fill=True,
        fill_color=get_color(row['Arithmetic Mean'], min_val, max_val),
        fill_opacity=0.7,
        popup=popup_text
    ).add_to(marker_cluster)

print("saving map")
# Save the map
m.save('ozone_map_emission_industry_v3.html')

