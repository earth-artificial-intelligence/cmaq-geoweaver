import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import shap
import numpy as np
import plotly.express as px

# Load the data
filepath = "/Users/sahiti/Downloads/updated_training_one_sites.csv"
df = pd.read_csv(filepath)

# Drop rows with missing values
df = df.dropna()

# Print column names
print(df.columns)
print(df['hours'].unique())

# Select a few random station IDs
# unique_stations = df['StationID'].unique()
# selected_stations = np.random.choice(unique_stations, 6, replace=False)
# df_selected = df[df['StationID'].isin(selected_stations)]
# 

# Specify the counties you want to include
specified_counties = ['Kewaunee County', 'Cedar County', 'Riverside County', 'Bruce County', 'Washington County', 'Taylor County']
df_selected = df[df['County'].isin(specified_counties)]

# pick which time to keep standard
df_selected = df_selected[df_selected['hours'] == 14]

# Ensure 'County' is included in the DataFrame
print(df_selected['County'].unique())

# Select features and target variable, excluding the 'County' column during training
X = df_selected.drop(labels=['CMAQ12KM_O3(ppb)', 'AirNOW_O3', 'StationID', 'Latitude_x', 'Longitude_x', 'Latitude_y', 'Longitude_y', 'month', 'hours', 'day', 'County'], axis=1)
y = df_selected['AirNOW_O3']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the XGBoost model
params = {"learning_rate": 0.01, "max_depth": 4}
dtrain = xgb.DMatrix(X_train, label=y_train)
bst = xgb.train(params, dtrain, num_boost_round=1000)

# Testing the XGBoost model
dtest = xgb.DMatrix(X_test)
y_pred = bst.predict(dtest)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"RMSE: {rmse}")

# Calculate feature importance
importance_df = pd.DataFrame({
    'Feature': bst.get_score(importance_type='weight').keys(),
    'Importance': bst.get_score(importance_type='weight').values()
}).sort_values(by='Importance', ascending=False)

print("XGBoost Feature Importances:")
print(importance_df)

# Initialize the SHAP explainer
explainer = shap.Explainer(bst, X_train)

# Calculate SHAP values
shap_values = explainer(X_test)

# Get the feature importances from SHAP values
shap_importance_df = pd.DataFrame({
    'Feature': X.columns,
    'Importance': np.mean(np.abs(shap_values.values), axis=0)
}).sort_values(by='Importance', ascending=False)

print("SHAP Feature Importances:")
print(shap_importance_df)

# Identify the most important feature per row
shap_values_abs = np.abs(shap_values.values)
most_important_features_per_row = X_test.columns[np.argmax(shap_values_abs, axis=1)]
df_most_important_per_row = pd.DataFrame({
    'Most Important Feature': most_important_features_per_row
})

# Print the most important feature for the first few rows
print("Most Important Feature per Row:")
print(df_most_important_per_row.head())

# Select top 7 important features for scatter plots
top_features = importance_df['Feature'].head(11).values

# Create scatter plots for the top 7 features with county names
for feature in top_features:
    fig = px.scatter(df_selected, x=feature, y='AirNOW_O3', color='County',
                     title=f'GMU Data: Scatter plot of {feature} vs AirNOW_O3',
                     labels={'County': 'County'},
                     color_discrete_sequence=px.colors.qualitative.Plotly)
    fig.update_layout(
        xaxis_title=feature,
        yaxis_title='AirNOW_O3',
        xaxis=dict(showgrid=True, zeroline=True),
        yaxis=dict(showgrid=True, zeroline=True)
    )
    fig.show()

# Plot SHAP summary plot
shap.summary_plot(shap_values, X_test)
plt.show()

# Plot SHAP dependence plot for a specific feature
shap.dependence_plot("SO2", shap_values, X_test)
plt.show()

