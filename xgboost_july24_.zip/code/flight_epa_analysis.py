# Write your first Python code in Geoweaver
import pandas as pd
import requests
import matplotlib.pyplot as plt
from scipy.stats import pearsonr, spearmanr
import numpy as np
import statsmodels.api as sm

file_path = '/Users/sahiti/Downloads/updated_flight.xlsx' 
flight_df = pd.read_excel(file_path)

flight_df = flight_df.rename(columns = {"COUNTY NAME": "County"})
print(flight_df.columns)

ozone = "/Users/sahiti/Downloads/ozone_2021/ozone_2021.csv"
castnet_site_id = "/Users/sahiti/Downloads/site_id_castnet_county.csv"

ozone_data = pd.read_csv(ozone)
print(ozone_data)
site_id_flight_df = pd.read_csv(castnet_site_id)

# Convert the DATE_TIME column to datetime
ozone_data['DATE_TIME'] = pd.to_datetime(ozone_data['DATE_TIME'])

# Extract year, month, day, and hour from the DATE_TIME
ozone_data['Year'] = ozone_data['DATE_TIME'].dt.year
ozone_data['Month'] = ozone_data['DATE_TIME'].dt.month
ozone_data['Day'] = ozone_data['DATE_TIME'].dt.date
ozone_data['Hour'] = ozone_data['DATE_TIME'].dt.hour

# Merge ozone data with site ID data to get county information
site_id_flight_df.rename(columns={'Latitude': 'lat_castnet', 'Longitude': 'Lon_castnet'}, inplace=True)
merged_castnet_flight_df = ozone_data.merge(site_id_flight_df, on='SITE_ID', how='left')

# Standardize county names
def standardize_county_name(county_name):
    return county_name.strip().upper().replace(' COUNTY', '')

merged_castnet_flight_df = merged_castnet_flight_df.fillna("")
merged_castnet_flight_df['County'] = merged_castnet_flight_df['County'].str.strip().str.upper()
merged_castnet_flight_df['County'] = merged_castnet_flight_df['County'].apply(standardize_county_name)
flight_df = flight_df.dropna()
flight_df['County'] = flight_df['County'].apply(standardize_county_name)
print(flight_df['County'])

filtered_data = merged_castnet_flight_df[(merged_castnet_flight_df['Month'] == 7) & (merged_castnet_flight_df['Hour'] == 14)]
#filtered_data.fillna(0, inplace=True)

final_df = filtered_data.merge(flight_df, on='County', how='left')
final_df = final_df.drop("OZONE_F", axis=1)
final_df = final_df.dropna()
print(final_df)

# Ensure 'GHG QUANTITY (METRIC TONS CO2e)' column is numeric
final_df['GHG QUANTITY (METRIC TONS CO2e)'] = pd.to_numeric(final_df['GHG QUANTITY (METRIC TONS CO2e)'], errors='coerce')
final_df['OZONE'] = pd.to_numeric(final_df['OZONE'], errors='coerce')

# Drop rows with NaN values in 'GHG QUANTITY (METRIC TONS CO2e)' after conversion
final_df = final_df.dropna(subset=['GHG QUANTITY (METRIC TONS CO2e)'])
print(final_df['GHG QUANTITY (METRIC TONS CO2e)'].dtype)
# Drop rows with NaN or infinite values in 'GHG QUANTITY (METRIC TONS CO2e)' and 'OZONE'
final_df = final_df.replace([np.inf, -np.inf], np.nan).dropna(subset=['GHG QUANTITY (METRIC TONS CO2e)', 'OZONE'])

# Pearson and Spearman correlations for GHG QUANTITY (METRIC TONS CO2e)
pearson_corr, pearson_p = pearsonr(final_df['OZONE'], final_df['GHG QUANTITY (METRIC TONS CO2e)'])
spearman_corr, spearman_p = spearmanr(final_df['OZONE'], final_df['GHG QUANTITY (METRIC TONS CO2e)'])
print(f"Pearson correlation: {pearson_corr}, p-value: {pearson_p}")
print(f"Spearman correlation: {spearman_corr}, p-value: {spearman_p}")

# Plotting the relationship between Ozone and GHG QUANTITY (METRIC TONS CO2e)
plt.figure(figsize=(8, 6))
plt.scatter(final_df['GHG QUANTITY (METRIC TONS CO2e)'], final_df['OZONE'], alpha=0.6)
plt.xlabel('GHG QUANTITY (METRIC TONS CO2e)')
plt.ylabel('Ozone Level')
plt.title('Relationship between Ozone Levels and GHG QUANTITY (METRIC TONS CO2e) in July at 2 PM')
plt.grid(True)
plt.show()

# Cluster ozone levels into low, medium, high
ozone_levels = final_df['OZONE'].values
clusters = pd.qcut(ozone_levels, q=3, labels=['Low', 'Medium', 'High'])

# Add the clusters to the DataFrame
final_df['Ozone_Level_Cluster'] = clusters

# Perform regression analysis
X = final_df[['GHG QUANTITY (METRIC TONS CO2e)']]
X = sm.add_constant(X)  # Adds a constant term to the predictor
y = final_df['OZONE']

model = sm.OLS(y, X).fit()
print(model.summary())

# Visualize cluster analysis
plt.figure(figsize=(10, 6))
colors = {'Low': 'blue', 'Medium': 'orange', 'High': 'green'}
for cluster in clusters.unique():
    cluster_data = final_df[final_df['Ozone_Level_Cluster'] == cluster]
    plt.scatter(cluster_data['GHG QUANTITY (METRIC TONS CO2e)'], cluster_data['OZONE'], alpha=0.6, label=f'{cluster} Ozone Cluster', color=colors[cluster])

# Plot centroids
centroids = final_df.groupby('Ozone_Level_Cluster').mean()
plt.scatter(centroids['GHG QUANTITY (METRIC TONS CO2e)'], centroids['OZONE'], s=100, color='red', marker='X', label='Centroids')

plt.xlabel('GHG QUANTITY (METRIC TONS CO2e)')
plt.ylabel('Ozone Level')
plt.title('Cluster Analysis of Ozone Levels and GHG QUANTITY (METRIC TONS CO2e)')
plt.legend()
plt.grid(True)
plt.show()

# Create a summary table listing counties in each ozone level cluster
ozone_cluster_summary = final_df.groupby('Ozone_Level_Cluster')['County'].apply(lambda x: list(x.unique())).reset_index()

# Summary statistics by cluster
summary_stats = final_df.groupby('Ozone_Level_Cluster')[['OZONE', 'GHG QUANTITY (METRIC TONS CO2e)']].describe()
print(summary_stats)

# Check the unique counties in each cluster
print("Counties in each Ozone Level Cluster:\n", ozone_cluster_summary)



# Visualize emissions by subparts
# Split subparts and explode into individual rows
subparts_expanded = final_df.assign(Subparts=final_df['SUBPARTS'].str.split(',')).explode('Subparts')

# Aggregate GHG quantities by subparts
subparts_agg = subparts_expanded.groupby('Subparts')['GHG QUANTITY (METRIC TONS CO2e)'].sum().reset_index()

# Sort by GHG quantity for better visualization
subparts_agg = subparts_agg.sort_values(by='GHG QUANTITY (METRIC TONS CO2e)', ascending=False)

# Plotting the emissions by subparts
plt.figure(figsize=(12, 8))
plt.bar(subparts_agg['Subparts'], subparts_agg['GHG QUANTITY (METRIC TONS CO2e)'], color='skyblue')
plt.xlabel('Subparts')
plt.ylabel('Total GHG QUANTITY (METRIC TONS CO2e)')
plt.title('Total GHG Emissions by Subparts')
plt.xticks(rotation=90)
plt.grid(True)
#plt.show()

# Calculate average ozone levels by subparts
subparts_ozone = subparts_expanded.groupby('Subparts')['OZONE'].mean().reset_index()

# Sort by average ozone levels for better visualization
subparts_ozone = subparts_ozone.sort_values(by='OZONE', ascending=False)

# Plotting the average ozone levels by subparts
plt.figure(figsize=(12, 8))
plt.bar(subparts_ozone['Subparts'], subparts_ozone['OZONE'], color='lightgreen')
plt.xlabel('Subparts')
plt.ylabel('Average Ozone Level')
plt.title('Average Ozone Levels by Subparts')
plt.xticks(rotation=90)
plt.grid(True)
plt.show()

