import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ozone = "/Users/sahiti/Downloads/ozone_2021/ozone_2021.csv"
castnet_site_id = "/Users/sahiti/Downloads/site_id_castnet_county.csv"
cbp_path = "/Users/sahiti/Downloads/CBP2021Data.csv"
updated_flight_path = '/Users/sahiti/Downloads/updated_flight.xlsx'
rural_atlas = "/Users/sahiti/Downloads/RuralAtlasData24.xlsx"
mapping_df_flight_epa_path = "/Users/sahiti/Downloads/mapping_df_flight_epa.csv"

ozone_data = pd.read_csv(ozone)
rural_atlas_data = pd.read_excel(rural_atlas)
cbp_data = pd.read_csv(cbp_path)
updated_flight_data = pd.read_excel(updated_flight_path)
site_id_df = pd.read_csv(castnet_site_id)
mapping_df_flight_epa = pd.read_csv(mapping_df_flight_epa_path)

ozone_data['DATE_TIME'] = pd.to_datetime(ozone_data['DATE_TIME'])


# Extract hour from the DATE_TIME
ozone_data['Year'] = ozone_data['DATE_TIME'].dt.year
ozone_data['Month'] = ozone_data['DATE_TIME'].dt.month
ozone_data['Day'] = ozone_data['DATE_TIME'].dt.date
ozone_data['Hour'] = ozone_data['DATE_TIME'].dt.hour

# Merge ozone data with site ID data to get county information
site_id_df.rename(columns={'Latitude': 'lat_castnet', 'Longitude': 'Lon_castnet'}, inplace=True)
merged_castnet_df = ozone_data.merge(site_id_df, on='SITE_ID', how='left')

# Load socioeconomic data from the relevant sheets
people_df = pd.read_excel(rural_atlas, sheet_name='People')
job_df = pd.read_excel(rural_atlas, sheet_name='Jobs')
county_df = pd.read_excel(rural_atlas, sheet_name='County Classifications')
income_df = pd.read_excel(rural_atlas, sheet_name='Income')
veteran_df = pd.read_excel(rural_atlas, sheet_name='Veterans')

# Drop unnecessary columns
job_df = job_df.drop(columns=['State'])
county_df = county_df.drop(columns=['State'])
income_df = income_df.drop(columns=['State'])
veteran_df = veteran_df.drop(columns=['State', 'FIPS'])

# Merge the socioeconomic data by county
merged_socio_df = people_df.merge(job_df, on='County', how='left')
merged_socio_df = merged_socio_df.merge(county_df, on='County', how='left')
merged_socio_df = merged_socio_df.merge(income_df, on='County', how='left')
#merged_socio_df = merged_socio_df.merge(veteran_df, on='County', how='left')

# Drop duplicates and NaNs

merged_socio_df = merged_socio_df.loc[:, ~merged_socio_df.columns.duplicated()].copy()

# Standardize county names
def standardize_county_name(county_name):
    return county_name.strip().upper().replace(' COUNTY', '')

merged_castnet_df = merged_castnet_df.fillna("")
merged_castnet_df['County'] = merged_castnet_df['County'].str.strip().str.upper()
merged_castnet_df['County'] = merged_castnet_df['County'].apply(standardize_county_name)
merged_socio_df['County'] = merged_socio_df['County'].str.strip().str.upper()
print("merged castnet", merged_castnet_df["County"].unique())

# Process CBP data
cbp_data[['County', 'State']] = cbp_data['Geographic Area Name'].str.split(',', expand=True)
cbp_data['County'] = cbp_data['County'].str.strip().str.upper()
cbp_data['County'] = cbp_data['County'].apply(standardize_county_name)
cbp_columns = ['County', '2017 NAICS code', 'Industry', 'Number of establishments', 'Number of employees', 'Employment size', 'Noise range for number of employees']
cbp_data = cbp_data[cbp_columns]

cbp_data.fillna(0, inplace=True)
cbp_pivot = cbp_data.pivot_table(index='County', columns='2017 NAICS code', values=['Number of establishments', 'Number of employees', 'Employment size', 'Noise range for number of employees'], aggfunc='sum').reset_index()

# Flatten the multi-level column names
cbp_pivot.columns = ['_'.join([str(col[0]), str(col[1])]).strip() if col[1] != '' else col[0] for col in cbp_pivot.columns]

print(cbp_pivot.head())

# updated_flight_data = updated_flight_data.merge(mapping_df_flight_epa, on='Activity', how='left')
# updated_flight_data['County'] = updated_flight_data['COUNTY NAME'].str.strip().str.upper()
# updated_flight_data['County'] = updated_flight_data['County'].apply(standardize_county_name)
# 
# # Create dummy columns for each subpart
# subparts_dummies = updated_flight_data['SUBPARTS'].str.get_dummies(sep=', ')
# 
# # Concatenate the dummy columns with the original dataframe
# updated_flight_data = pd.concat([updated_flight_data, subparts_dummies], axis=1)
# 
# # Aggregate flight data by county, summing up the dummy variables
# flight_aggregated = updated_flight_data.groupby('County')[subparts_dummies.columns].sum().reset_index()
# print(flight_aggregated)
# 
# # Merge flight data with the final dataframe
# final_df = final_df.merge(flight_aggregated, on='County', how='left')


# Merge CBP data with castnet data
#final_df = merged_castnet_df.merge(cbp_pivot, on='County', how='left')



# Merge ozone data with socioeconomic data
final_df = merged_castnet_df.merge(merged_socio_df, on='County', how='left')
print(final_df["County"].unique())

# Save the final merged dataset to a CSV file
#final_df.to_csv('/mnt/data/final_merged_data.csv', index=False)

# Display the first few rows of the final merged dataset
print(final_df.head())

early_morning_data = merged_castnet_df[(merged_castnet_df['Hour'] >= 1) & (merged_castnet_df['Hour'] <= 3)]

# Display data points around 2 AM
print("Data points around 2 AM:")
print(early_morning_data[['County', 'DATE_TIME', 'OZONE', 'Hour']])
print(final_df["County"].unique())

# Aggregate data to avoid clustering at specific hours
hourly_avg_ozone = merged_castnet_df.groupby(['Hour', 'County'])['OZONE'].mean().reset_index()

# Plot scatter plot of hourly ozone levels for all counties with aggregation
plt.figure(figsize=(12, 6))
for county in hourly_avg_ozone['County'].unique():
    county_data = hourly_avg_ozone[hourly_avg_ozone['County'] == county]
    plt.scatter(county_data['Hour'], county_data['OZONE'], label=county, alpha=0.5, s=10)

plt.title('Hourly Ozone Levels for All Counties')
plt.xlabel('Hour of the Day')
plt.ylabel('Ozone Level')
plt.grid(True)
plt.legend()
plt.show()


# Aggregate data by day to calculate daily average ozone levels
daily_avg_ozone = merged_castnet_df.groupby(['Day', 'County'])['OZONE'].mean().reset_index()

# Aggregate data by month to calculate monthly average ozone levels
monthly_avg_ozone = merged_castnet_df.groupby(['Year', 'Month', 'County'])['OZONE'].mean().reset_index()
monthly_avg_ozone['Date'] = pd.to_datetime(monthly_avg_ozone[['Year', 'Month']].assign(Day=1))

# Plot daily average ozone levels for all counties
plt.figure(figsize=(12, 6))
for county in daily_avg_ozone['County'].unique():
    county_data = daily_avg_ozone[daily_avg_ozone['County'] == county]
    plt.plot(county_data['Day'], county_data['OZONE'], label=county, alpha=0.5)

plt.title('Daily Average Ozone Levels for All Counties')
plt.xlabel('Day of the Year')
plt.ylabel('Ozone Level')
plt.grid(True)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.show()

# Plot monthly average ozone levels for all counties
plt.figure(figsize=(12, 6))
for county in monthly_avg_ozone['County'].unique():
    county_data = monthly_avg_ozone[monthly_avg_ozone['County'] == county]
    plt.plot(county_data['Date'], county_data['OZONE'], label=county, alpha=0.5)

plt.title('Monthly Average Ozone Levels for All Counties')
plt.xlabel('Month')
plt.ylabel('Ozone Level')
plt.grid(True)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.show()

