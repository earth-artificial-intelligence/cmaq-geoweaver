# Write your first Python code in Geoweaver

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearsonr, spearmanr

# Load the provided files
ozone = "/Users/sahiti/Downloads/ozone_2021/ozone_2021.csv"
castnet_site_id = "/Users/sahiti/Downloads/site_id_castnet_county.csv"
cbp_path = "/Users/sahiti/Downloads/CBP2021Data.csv"
rural_atlas = "/Users/sahiti/Downloads/RuralAtlasData24.xlsx"

ozone_data = pd.read_csv(ozone)
site_id_df = pd.read_csv(castnet_site_id)
cbp_data = pd.read_csv(cbp_path)
rural_atlas_data = pd.read_excel(rural_atlas)

# Convert the DATE_TIME column to datetime
ozone_data['DATE_TIME'] = pd.to_datetime(ozone_data['DATE_TIME'])

# Extract year, month, day, and hour from the DATE_TIME
ozone_data['Year'] = ozone_data['DATE_TIME'].dt.year
ozone_data['Month'] = ozone_data['DATE_TIME'].dt.month
ozone_data['Day'] = ozone_data['DATE_TIME'].dt.date
ozone_data['Hour'] = ozone_data['DATE_TIME'].dt.hour

# Merge ozone data with site ID data to get county information
site_id_df.rename(columns={'Latitude': 'lat_castnet', 'Longitude': 'Lon_castnet'}, inplace=True)
merged_castnet_df = ozone_data.merge(site_id_df, on='SITE_ID', how='left')



# Standardize county names
def standardize_county_name(county_name):
    return county_name.strip().upper().replace(' COUNTY', '')

merged_castnet_df = merged_castnet_df.fillna("")
merged_castnet_df['County'] = merged_castnet_df['County'].str.strip().str.upper()
merged_castnet_df['County'] = merged_castnet_df['County'].apply(standardize_county_name)


# Merge ozone data with socioeconomic data
final_df = merged_castnet_df
print(final_df.head())

# Process CBP data
cbp_data[['County', 'State']] = cbp_data['Geographic Area Name'].str.split(',', expand=True)
cbp_data['County'] = cbp_data['County'].str.strip().str.upper()
cbp_data['County'] = cbp_data['County'].apply(standardize_county_name)
cbp_columns = ['County', '2017 NAICS code', 'Industry', 'Number of establishments', 'Number of employees', 'Employment size', 'Noise range for number of employees']
cbp_data = cbp_data[cbp_columns]

cbp_data.fillna(0, inplace=True)
#cbp_pivot = cbp_data.pivot_table(index='County', columns='2017 NAICS code', values=['Number of establishments', 'Number of employees', 'Employment size', 'Noise range for number of employees'], aggfunc='sum').reset_index()
cbp_pivot = cbp_data.pivot_table(index='County', columns='Industry', values='Number of establishments', aggfunc='sum').reset_index()
for col in cbp_pivot.columns[1:]:  # Skip the 'County' column
    cbp_pivot[col] = pd.to_numeric(cbp_pivot[col], errors='coerce')

# Flatten the multi-level column names
#cbp_pivot.columns = ['_'.join([str(col[0]), str(col[1])]).strip() if col[1] != '' else col[0] for col in cbp_pivot.columns]
print(cbp_pivot.head())
# Function to map NAICS codes to industry names
def map_naics_to_industry(naics_code):
    industry_mapping = {
        '0': 'Agriculture_Forestry_Fishing_Hunting',
        '11': 'Mining_Quarrying_Oil_Gas_Extraction',
        '21': 'Utilities',
        '22': 'Construction',
        '23': 'Manufacturing',
        '31-33': 'Manufacturing',
        '42': 'Wholesale_Trade',
        '44-45': 'Retail_Trade',
        '48-49': 'Transportation_Warehousing',
        '51': 'Information',
        '52': 'Finance_Insurance',
        '53': 'Real_Estate_Rental_Leasing',
        '54': 'Professional_Scientific_Technical_Services',
        '55': 'Management_of_Companies_Enterprises',
        '56': 'Administrative_Support_Waste_Management_Remediation_Services',
        '61': 'Educational_Services',
        '62': 'Healthcare_Social_Assistance',
        '71': 'Arts_Entertainment_Recreation',
        '72': 'Accommodation_Food_Services',
        '81': 'Other_Services_except_Public_Administration',
        '99': 'Public_Administration'
    }
    return industry_mapping.get(naics_code, naics_code)

# Rename the columns using the industry mapping
# new_column_names = {}
# for col in cbp_pivot.columns:
#     if '_' in col:
#         prefix, naics_code = col.split('_')
#         industry_name = map_naics_to_industry(naics_code)
#         new_column_names[col] = f'{prefix}_{industry_name}'
# 
# cbp_pivot.rename(columns=new_column_names, inplace=True)
# print(cbp_pivot.columns)

# Merge industry-specific CBP data with filtered ozone data
filtered_data = final_df[(final_df['Month'] == 7) & (final_df['Hour'] == 14)]
filtered_data = filtered_data.merge(cbp_pivot, on='County', how='left')
for var in filtered_data.columns:
    filtered_data[var] = pd.to_numeric(filtered_data[var], errors='coerce')

filtered_data.fillna(0, inplace=True)

print(filtered_data)
# List of all industry-specific variables
#industry_vars = [col for col in filtered_data.columns if any(prefix in col for prefix in ['Number of establishments', 'Employment size'])]
industry_vars = [col for col in filtered_data.columns if col not in ['County', 'Year', 'Month', 'Day', 'Hour', 'OZONE']]

# Calculate Pearson and Spearman correlations for industry-specific CBP data
industry_correlation_results = []

for var in industry_vars:
    if var in filtered_data.columns:
        pearson_corr, pearson_p = pearsonr(filtered_data['OZONE'], filtered_data[var])
        spearman_corr, spearman_p = spearmanr(filtered_data['OZONE'], filtered_data[var])
        industry_correlation_results.append({
            'Variable': var,
            'Pearson Correlation': pearson_corr,
            'Pearson p-value': pearson_p,
            'Spearman Correlation': spearman_corr,
            'Spearman p-value': spearman_p
        })

industry_correlation_df = pd.DataFrame(industry_correlation_results)
print(industry_correlation_df)

# Plotting correlation results for industry-specific CBP data
plt.figure(figsize=(12, 6))
plt.bar(industry_correlation_df['Variable'], industry_correlation_df['Pearson Correlation'], alpha=0.6, label='Pearson')
plt.bar(industry_correlation_df['Variable'], industry_correlation_df['Spearman Correlation'], alpha=0.6, label='Spearman')
plt.xlabel('CBP Industry Variable')
plt.ylabel('Correlation with Ozone Level')
plt.title('Correlation between Ozone Levels and Industry-Specific CBP Variables in July')
plt.legend()
plt.xticks(rotation=90)
plt.grid(True)
plt.show()

filtered_data = filtered_data.dropna(subset=industry_vars + ['OZONE'])

for var in industry_vars:
    plt.figure(figsize=(8, 6))
    plt.scatter(filtered_data[var], filtered_data['OZONE'], alpha=0.6)
    plt.xlabel(var)
    plt.ylabel('Ozone Level')
    plt.title(f'Relationship between Ozone Levels and {var} in July at 2 PM')
    plt.grid(True)
    plt.show()

