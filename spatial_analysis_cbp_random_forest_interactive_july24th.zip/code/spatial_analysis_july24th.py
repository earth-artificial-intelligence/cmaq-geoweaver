# Write your first Python code in Geoweaver
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import pearsonr, spearmanr
from sklearn.linear_model import LinearRegression
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score
from sklearn.inspection import PartialDependenceDisplay
import geopandas as gpd
from esda.moran import Moran
from libpysal.weights import Queen
import shap
import folium
from folium.plugins import MarkerCluster
from folium import Choropleth
from matplotlib.colors import Normalize, to_hex
import matplotlib.cm as cm

# Load the datasets
annual_conc = pd.read_csv('/Users/madhav/Downloads/annual_conc_by_monitor_2021.csv')
cbp_data = pd.read_csv('/Users/madhav/Downloads/CBP2021Data.csv')

# Rename 'Geographic identifier code' to 'County Code' in the CBP data
cbp_data.rename(columns={'Geographic identifier code': 'County Code'}, inplace=True)

# Convert 'County Code' to string and create a combined county code in both datasets
annual_conc['County Code'] = annual_conc['County Code'].astype(str).str.zfill(3)
annual_conc['Combined County Code'] = annual_conc['State Code'].astype(str).str.zfill(2) + annual_conc['County Code']

cbp_data['County Code'] = cbp_data['County Code'].astype(str).str.zfill(5)
cbp_data['Combined County Code'] = cbp_data['County Code'].apply(lambda x: x[-5:])

# Pivot the CBP data to have industries as columns and the number of establishments as values
cbp_pivot = cbp_data.pivot_table(
    index='Combined County Code', 
    columns='Industry', 
    values='Number of establishments', 
    aggfunc='sum'
).reset_index()

# Drop 'Industries not classified' column if it exists
cbp_pivot = cbp_pivot.drop(columns=['Industries not classified'], errors='ignore')

# Merge the pivoted CBP data with the annual concentration data based on Combined County Code
merged_data = pd.merge(annual_conc, cbp_pivot, how='left', left_on='Combined County Code', right_on='Combined County Code')

# Drop specified columns from the merged dataset
columns_to_drop = [
    '1st Max Non Overlapping Value', 
    '1st NO Max DateTime', 
    '2nd Max Non Overlapping Value', 
    '2nd NO Max DateTime'
]
merged_data.drop(columns=columns_to_drop, inplace=True)

# Display the first few rows of the pivoted CBP data to verify
print(cbp_pivot.info())
print(annual_conc.info())
print(merged_data.head())

# Step 1: Descriptive Statistics

# Descriptive statistics for ozone levels
ozone_data = merged_data[merged_data['Parameter Name'] == 'Ozone']['Arithmetic Mean']
ozone_summary = {
    'mean': ozone_data.mean(),
    'median': ozone_data.median(),
    'std_dev': ozone_data.std(),
    'range': (ozone_data.min(), ozone_data.max())
}

# Descriptive statistics for socioeconomic variables (number of establishments in various industries)
socioeconomic_summary = merged_data.describe()

print("Ozone Summary Statistics:\n", ozone_summary)
print("\nSocioeconomic Summary Statistics:\n", socioeconomic_summary)


# Step 2: Visualization

# Histogram of Ozone Levels
plt.figure(figsize=(10, 6))
sns.histplot(ozone_data, bins=30, kde=True)
plt.title('Distribution of Ozone Levels')
plt.xlabel('Ozone Level (Arithmetic Mean)')
plt.ylabel('Frequency')
plt.show()

# Box Plot of Ozone Levels
plt.figure(figsize=(10, 6))
sns.boxplot(x=ozone_data)
plt.title('Box Plot of Ozone Levels')
plt.xlabel('Ozone Level (Arithmetic Mean)')
plt.show()

# Scatter Plots for All Industries vs. Ozone Levels
industries = cbp_pivot.columns[1:]  # All industry columns excluding 'Combined County Code'
# for industry in industries:
#     industry_data = merged_data[merged_data['Parameter Name'] == 'Ozone'][industry]
#     plt.figure(figsize=(10, 6))
#     sns.scatterplot(x=industry_data, y=ozone_data)
#     plt.title(f'Scatter Plot of {industry} Establishments vs. Ozone Levels')
#     plt.xlabel(f'Number of {industry} Establishments')
#     plt.ylabel('Ozone Level (Arithmetic Mean)')
#     plt.show()

# Step 3: Correlation Analysis

# Pearson and Spearman Correlation for All Industries vs. Ozone Levels
correlation_results = {}
for industry in industries:
    industry_data = merged_data[merged_data['Parameter Name'] == 'Ozone'][industry].fillna(0)
    pearson_corr, _ = pearsonr(industry_data, ozone_data.fillna(0))
    spearman_corr, _ = spearmanr(industry_data, ozone_data.fillna(0))
    correlation_results[industry] = {
        'pearson': pearson_corr,
        'spearman': spearman_corr
    }

print("Correlation Results:\n", correlation_results)

# Step 4: Regression Analysis

# Simple Linear Regression
simple_lr_results = {}
for industry in industries:
    industry_data = merged_data[merged_data['Parameter Name'] == 'Ozone'][industry].fillna(0).values.reshape(-1, 1)
    lr = LinearRegression().fit(industry_data, ozone_data.fillna(0))
    simple_lr_results[industry] = {
        'coef': lr.coef_[0],
        'intercept': lr.intercept_,
        'r2': lr.score(industry_data, ozone_data.fillna(0))
    }

print("Simple Linear Regression Results:\n", simple_lr_results)

# Multiple Linear Regression
X = merged_data[merged_data['Parameter Name'] == 'Ozone'][industries].fillna(0)
y = ozone_data.fillna(0)
mlr = LinearRegression().fit(X, y)
multiple_lr_results = {
    'coefs': mlr.coef_,
    'intercept': mlr.intercept_,
    'r2': mlr.score(X, y)
}

print("Multiple Linear Regression Results:\n", multiple_lr_results)

# Step 5: Spatial Analysis

# Ensure y and gdf are aligned
gdf = gpd.GeoDataFrame(merged_data, geometry=gpd.points_from_xy(merged_data['Longitude'], merged_data['Latitude']))
gdf.set_crs(epsg=4326, inplace=True)  # Set CRS to WGS 84
y_aligned = y.reset_index(drop=True)
gdf = gdf.loc[y_aligned.index]

# Spatial Autocorrelation (Moran's I)
w = Queen.from_dataframe(gdf, use_index=False)
moran = Moran(y_aligned.values, w)
print("Moran's I Results:\n", moran.I)

# Step 6: Data Preparation and Analysis

# Filter for only ozone data
ozone_data_filtered = merged_data[merged_data['Parameter Name'] == 'Ozone']
X = ozone_data_filtered[industries].fillna(0)
y = ozone_data_filtered['Arithmetic Mean'].fillna(0)

# Principal Component Analysis (PCA)
pca = PCA(n_components=2)
pca_result = pca.fit_transform(X)
print("PCA Results:\n", pca_result)

# Random Forest Regression
rf = RandomForestRegressor(n_estimators=100, random_state=42)
rf.fit(X, y)
rf_predictions = rf.predict(X)
rf_mse = mean_squared_error(y, rf_predictions)
rf_r2 = r2_score(y, rf_predictions)
print("Random Forest MSE:\n", rf_mse)
print("Random Forest R^2:", rf_r2)

# Feature Importance
feature_importances = pd.DataFrame(rf.feature_importances_, index=X.columns, columns=['importance']).sort_values('importance', ascending=False)
print("Feature Importances:\n", feature_importances)

# Determine the main contributor for each area using SHAP values
explainer = shap.TreeExplainer(rf)
shap_values = explainer.shap_values(X)

# Determine main contributor for each area
main_contributors = []
main_contributors_values = []

for i in range(X.shape[0]):
    shap_vals = shap_values[i]
    max_shap_idx = np.argmax(np.abs(shap_vals))
    main_contributors.append(X.columns[max_shap_idx])
    main_contributors_values.append(shap_vals[max_shap_idx])

# Create a DataFrame for the main contributors
contributor_df = pd.DataFrame({
    'Main Contributor': main_contributors,
    'Main Contributor Value': main_contributors_values
}, index=X.index)

# Merge the main contributor information back into the ozone_data_filtered DataFrame
ozone_data_filtered['Main Contributor'] = contributor_df['Main Contributor']
ozone_data_filtered['Main Contributor Value'] = contributor_df['Main Contributor Value']

# Check for NaN values in the 'Main Contributor' and 'Main Contributor Value' columns
nan_contributors = ozone_data_filtered['Main Contributor'].isna().sum()
nan_contributors_values = ozone_data_filtered['Main Contributor Value'].isna().sum()
print("Number of NaN values in 'Main Contributor':", nan_contributors)
print("Number of NaN values in 'Main Contributor Value':", nan_contributors_values)


# Function to normalize and convert ozone levels to a color
def get_color(ozone_level, min_val, max_val):
    norm = Normalize(vmin=min_val, vmax=max_val)
    cmap = cm.get_cmap('YlOrRd')
    return to_hex(cmap(norm(ozone_level)))

# Base map
m = folium.Map(location=[37.7749, -122.4194], zoom_start=5)  # Centered on California

# Get min and max ozone levels for normalization
min_ozone = ozone_data_filtered['Arithmetic Mean'].min()
max_ozone = ozone_data_filtered['Arithmetic Mean'].max()

# Add markers to the map with color coding
for idx, row in ozone_data_filtered.iterrows():
    if pd.notna(row['Arithmetic Mean']) and pd.notna(row['Latitude']) and pd.notna(row['Longitude']):
        color = get_color(row['Arithmetic Mean'], min_ozone, max_ozone)
        popup_text = f"Ozone Level: {row['Arithmetic Mean']}<br>"
        
        # Ensure main contributor is not NaN or 'nan'
        if pd.notna(row['Main Contributor']) and row['Main Contributor'] != 'nan':
            popup_text += f"Main Contributor: {row['Main Contributor']}<br>"
        
        if pd.notna(row['Main Contributor Value']) and row['Main Contributor Value'] != 'nan':
            popup_text += f"Contributor Value: {row['Main Contributor Value']}"
        
        folium.CircleMarker(
            location=[row['Latitude'], row['Longitude']],
            radius=5,
            color=color,
            fill=True,
            fill_color=color,
            fill_opacity=0.7,
            popup=folium.Popup(popup_text, max_width=300)
        ).add_to(m)

# Save the map to an HTML file
m.save('ozone_levels_map_v8.html')

# Prepare data for interactive dashboards
merged_data.to_csv('merged_data_for_dashboard_v8.csv', index=False)

print("Geospatial map saved as 'ozone_levels_map_v8.html'")
print("Merged data saved as 'merged_data_for_dashboard.csv'")

