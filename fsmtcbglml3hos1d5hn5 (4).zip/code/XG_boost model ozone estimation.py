# Write your first Python code in Geoweaver
import pandas as pd
from xgboost.sklearn import XGBRegressor
from sklearn.ensemble import VotingRegressor
import math
import sklearn
from sklearn.metrics import mean_squared_error
import time
import shap
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split

filepath= "/Users/sahiti/Downloads/training_one_year.csv"

df = pd.read_csv(filepath)
df=df.dropna()
print(df.columns)

#TRAINING THE MODEL
X = df.drop(labels=['CMAQ12KM_O3(ppb)','AirNOW_O3', 'StationID', 'Latitude_x', 'Longitude_x', 'Latitude_y','Longitude_y'], axis=1)

y = df['AirNOW_O3']

#split training and test data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

#training the xgboost model
params = {"learning_rate": 0.01, "max_depth": 4}
dtrain = xgb.DMatrix(X_train, label=y_train)
bst = xgb.train(params, dtrain, num_boost_round=1000)

#testing the xgboost model
dtest = xgb.DMatrix(X_test)
y_pred = bst.predict(dtest)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"RMSE: {rmse}")

# Get SHAP values
dtrain_full = xgb.DMatrix(X)  # For SHAP values, use the entire dataset
shap_values = bdt.predict(dtrain_full, pred_contribs=True)
shap_df = pd.DataFrame(shap_values, columns=X.columns)

# Save SHAP values to a CSV
shap_df.to_csv("shap_feature_importance_jul5.csv", index=False)

print(shap_values)

# To visualize SHAP values
explainer = shap.Explainer(bst, dtrain_full)
shap_values = explainer(X)

# Summary plot
shap.summary_plot(shap_values, X)


# define the base models
#models = list()
#models.append(('XGB1', XGBRegressor(max_depth=1)))
#models.append(('XGB2', XGBRegressor(max_depth=2)))
#models.append(('XGB3', XGBRegressor(max_depth=3)))
#models.append(('XGB4', XGBRegressor(max_depth=4)))
#models.append(('XGB5', XGBRegressor(max_depth=5)))
#models.append(('XGB6', XGBRegressor(max_depth=6)))
# define the voting ensemble
#ensemble = VotingRegressor(estimators=models)
# fit the model on all available data
#ensemble.fit(X, y)

#TESTING THE MODEL
#X_test = df[900:].drop(labels=['CMAQ12KM_O3(ppb)','AirNOW_O3', 'StationID', 'Latitude_x', 'Longitude_x', 'Latitude_y','Longitude_y'], axis=1)

#y_test = df[900:]['AirNOW_O3']

#pred = ensemble.predict(X_test)

#mse = sklearn.metrics.mean_squared_error(pred, y_test)
#rmse = math.sqrt(mse)
#print(mse, rmse)


#bst = xgboost.train({"learning_rate": 0.01, "max_depth": 4}, xgboost.DMatrix(X, label=y), 1000)

#print(X.columns)
#start = time.time()
#shap_values = bst.predict(xgboost.DMatrix(X), #pred_contribs=True)

#shap_df = pd.DataFrame(shap_values)
#shap_df.to_csv("shap_feature_importance.csv")
#print(shap_values)





