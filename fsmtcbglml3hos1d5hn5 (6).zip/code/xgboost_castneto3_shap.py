import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import xgboost as xgb
import shap
import matplotlib.pyplot as plt
import numpy as np
import plotly.express as px

# Load the data
merged_df = pd.read_csv('/Users/sahiti/Downloads/merged_ozone_df_county_training.csv')

# Select only the air pollutant columns as features
air_pollutant_columns = ['Ca', 'Cl', 'HNO3', 'K', 'Mg', 'Na', 'NH4', 'NO3', 'SO2', 'SO4', 'TNO3']
features = merged_df[air_pollutant_columns]
target = merged_df['OZONE']

# Ensure all feature columns are numeric
features = features.apply(pd.to_numeric, errors='coerce')

# Ensure target variable has no NaN or infinite values
target = target.replace([float('inf'), -float('inf')], float('nan')).dropna()

# Align features and target to have matching indices
features, target = features.align(target, join='inner', axis=0)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# Initialize the XGBoost model
xgb_model = xgb.XGBRegressor(objective='reg:squarederror', random_state=42)

# Train the model
xgb_model.fit(X_train, y_train)

# Make predictions (not necessary for SHAP but useful for evaluation)
predictions = xgb_model.predict(X_test)

# Calculate RMSE
rmse = np.sqrt(mean_squared_error(y_test, predictions))
print(f'Root Mean Squared Error (RMSE): {rmse}')

# Calculate feature importance
importance_df = pd.DataFrame({
    'Feature': xgb_model.feature_names_in_,
    'Importance': xgb_model.feature_importances_
}).sort_values(by='Importance', ascending=False)

print(importance_df)

# Select top 7 important features
top_features = importance_df['Feature'].head(9).values
for feature in top_features:
    merged_df[feature] = pd.to_numeric(merged_df[feature], errors='coerce')


# Randomly select 6 counties

# Create scatter plots for the top 7 features with county names
for feature in top_features:
    fig = px.scatter(merged_df, x=feature, y='OZONE', color='County',
                     title=f'CASTNET Data: Scatter plot of {feature} vs OZONE',
                     labels={'County': 'County'},
                     color_discrete_sequence=px.colors.qualitative.Plotly)
    fig.update_layout(
        xaxis_title=feature,
        yaxis_title='OZONE',
        xaxis=dict(showgrid=True, zeroline=True, title=feature),
        yaxis=dict(showgrid=True, zeroline=True, title='OZONE')
    )
    fig.show()

# Initialize the SHAP explainer
explainer = shap.Explainer(xgb_model, X_train)

# Calculate SHAP values
shap_values = explainer(X_test)

# Plot SHAP summary plot
shap.summary_plot(shap_values, X_test, show=False)
plt.show()

# Plot SHAP dependence plot for a specific feature
shap.dependence_plot("SO2", shap_values, X_test, show=False)
plt.show()


