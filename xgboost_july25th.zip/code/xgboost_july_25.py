# Write your first Python code in Geoweaver
# Mount Google Drive
#from google.colab import drive
#drive.mount('/content/drive')

# Install required packages
#!pip install shap

from sklearn.model_selection import RandomizedSearchCV, train_test_split
from sklearn.metrics import mean_squared_error
import xgboost as xgb
import pandas as pd
import shap
import matplotlib.pyplot as plt
import numpy as np

# Load the data
df = pd.read_csv("/content/drive/MyDrive/assip_data/new_daily_air_data_merged.csv")

# Drop rows with missing values
df = df.dropna()

# Select features and target variable
X = df.drop(columns=['AQI', 'County Name', 'State Name', 'City Name', 'Address', 'Date Local', 'Unnamed: 0'])
y = df['AQI']

# Ensure all feature columns are numeric
X = X.apply(pd.to_numeric, errors='coerce')

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the XGBoost model with hyperparameter tuning
param_dist = {
    'learning_rate': [0.01, 0.1, 0.2],
    'max_depth': [3, 4, 5],
    'n_estimators': [100, 500, 1000],
    'subsample': [0.6, 0.8, 1.0],
    'colsample_bytree': [0.6, 0.8, 1.0]
}

xgb_model = xgb.XGBRegressor(objective='reg:squarederror', random_state=42)
random_search = RandomizedSearchCV(xgb_model, param_distributions=param_dist, n_iter=10, scoring='neg_mean_squared_error', cv=3, verbose=1, random_state=42)
random_search.fit(X_train, y_train)

# Get the best model
best_model = random_search.best_estimator_

# Predict and evaluate the model
y_pred = best_model.predict(X_test)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"RMSE: {rmse}")

# Initialize the SHAP explainer
explainer = shap.Explainer(best_model, X_train)

# Calculate SHAP values
shap_values = explainer(X_test)

# Plot SHAP summary plot
shap.summary_plot(shap_values, X_test)
plt.show()

# Plot SHAP dependence plot for a specific feature
shap.dependence_plot("Sample Duration", shap_values, X_test)
plt.show()



